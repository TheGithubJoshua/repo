#!/bin/bash

# Function to change a line in a Debian control file
change_control_line() {
    file_path="$1"
    line_to_change="$2"
    new_line="$3"
    
    # Check if the file exists
    if [ ! -f "$file_path" ]; then
        echo "File '$file_path' not found."
        exit 1
    fi
    
    # Find the line number of the line to change
    line_number=$(grep -n "^$line_to_change" "$file_path" | cut -d: -f1)
    
    if [ -z "$line_number" ]; then
        echo "Line to change not found in the file."
        exit 1
    fi
    
    # Update the line with the new content
    sed -i "${line_number}s/.*/$new_line/" "$file_path"
    
    echo "Line changed successfully."
}

# Function to unpack a Debian package
unpack_deb() {
    deb_file="$1"
    temp_dir=$(mktemp -d)
    dpkg-deb -R "$deb_file" "$temp_dir"
    echo "$temp_dir"
}

# Function to repack a Debian package
repack_deb() {
    temp_dir="$1"
    deb_file="$2"
    dpkg-deb -b "$temp_dir" "$deb_file"
    echo "$deb_file"
}

# Example usage
deb_file=com.joshua.volumeflex_0.0.5-2_iphoneos-arm64.deb
temp_dir=$(unpack_deb "$deb_file")
control_file="$temp_dir/DEBIAN/control"

line_to_change='Depends:'
new_version_number='mobilesubstrate (>= 0.9.5000), libflex'
change_control_line "$control_file" "$line_to_change" "$new_version_number"

# Repack the Debian package
repack_deb "$temp_dir" "new_$deb_file"

